# Déploiement de l'Application Gredeco Quotation

## Contenu du fichier ZIP

- `dist/` : Tous les fichiers de l'application web
- `.env` : Variables d'environnement (contient les clés Supabase)

## Instructions de déploiement

### 1. Prérequis

Votre serveur web doit supporter:
- Servir des fichiers HTML/CSS/JavaScript statiques
- Apache, Nginx, IIS ou tout autre serveur web moderne

### 2. Installation sur le serveur

1. Décompressez le fichier `gredeco-quotation-app.zip`
2. Copiez le contenu du dossier `dist/` vers le répertoire racine de votre serveur web
3. Configurez votre serveur pour servir le fichier `index.html`

### 3. Configuration des variables d'environnement

Les variables Supabase sont déjà incluses dans le fichier `.env`. L'application est configurée pour utiliser Supabase Cloud.

**IMPORTANT**: Les clés Supabase dans le fichier `.env` sont:
- `VITE_SUPABASE_URL` : URL de votre projet Supabase
- `VITE_SUPABASE_ANON_KEY` : Clé publique (sécurisée pour utilisation côté client)

Ces variables sont déjà intégrées dans les fichiers JavaScript compilés.

### 4. Configuration serveur web

#### Apache (.htaccess)
Créez un fichier `.htaccess` dans le dossier `dist/`:
```apache
<IfModule mod_rewrite.c>
  RewriteEngine On
  RewriteBase /
  RewriteRule ^index\.html$ - [L]
  RewriteCond %{REQUEST_FILENAME} !-f
  RewriteCond %{REQUEST_FILENAME} !-d
  RewriteRule . /index.html [L]
</IfModule>
```

#### Nginx
```nginx
location / {
  try_files $uri $uri/ /index.html;
}
```

#### IIS (web.config)
```xml
<?xml version="1.0" encoding="UTF-8"?>
<configuration>
  <system.webServer>
    <rewrite>
      <rules>
        <rule name="SPA Routes" stopProcessing="true">
          <match url=".*" />
          <conditions logicalGrouping="MatchAll">
            <add input="{REQUEST_FILENAME}" matchType="IsFile" negate="true" />
            <add input="{REQUEST_FILENAME}" matchType="IsDirectory" negate="true" />
          </conditions>
          <action type="Rewrite" url="/" />
        </rule>
      </rules>
    </rewrite>
  </system.webServer>
</configuration>
```

### 5. Accès à l'application

Une fois déployée, accédez à l'application via:
- `http://votre-serveur.local/` ou
- `http://localhost/` (si déployé localement)

### 6. Base de données

L'application utilise Supabase Cloud pour la base de données. Aucune installation de base de données locale n'est nécessaire.

**Si vous souhaitez héberger Supabase localement:**
1. Installez Supabase Self-Hosted: https://supabase.com/docs/guides/self-hosting
2. Mettez à jour les variables d'environnement avec votre instance locale
3. Reconstruisez l'application avec `npm run build`

### 7. Sécurité

- Les clés Supabase incluses sont sécurisées pour utilisation côté client
- La sécurité des données est gérée par les politiques RLS (Row Level Security) dans Supabase
- Assurez-vous que votre serveur utilise HTTPS en production

### Support

Pour toute question ou problème, contactez votre administrateur système.
